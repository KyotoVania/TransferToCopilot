import os
import sys
import zipfile
import shutil

# --- CONFIGURATION ---

# 1. Configuration pour la consolidation de code
NOM_FICHIER_BUNDLE = "Code_Bundle.txt"
EXTENSION_A_INCLURE = ".cs"
DOSSIERS_A_EXCLURE_BUNDLE = ["bin", "obj", ".vs", ".idea", "Logs", "UserSettings"]

# 2. Configuration pour la création de l'archive ZIP
# Le nom du dossier contenant le projet (le script s'attend à être à la racine)
# Il est détecté automatiquement, mais peut être forcé si besoin.
NOM_DOSSIER_PROJET = os.path.basename(os.getcwd())
DOSSIERS_A_EXCLURE_ZIP = ['.idea', 'Logs', 'Library', 'Temp', 'obj', 'Build', 'UserSettings']
FICHIERS_A_EXCLURE_ZIP = ['.sln', '.user', '.csproj.DotSettings']

# --- FIN DE LA CONFIGURATION ---


def afficher_menu():
    """Affiche le menu principal et gère la sélection de l'utilisateur."""
    while True:
        print("\n" + "="*40)
        print("===== UTILITAIRE DE PROJET PYTHON =====")
        print("="*40)
        print("  1. Consolider le code en un seul fichier (.txt)")
        print("  2. Créer une archive ZIP du projet (sans les fichiers .meta)")
        print("  3. Quitter")
        print("="*40)

        choix = input("Votre choix [1-3] : ")

        if choix == '1':
            creer_bundle()
        elif choix == '2':
            lancer_creation_zip()
        elif choix == '3':
            print("Au revoir !")
            break
        else:
            print("Choix invalide, veuillez réessayer.")


def creer_bundle():
    """Parcourt le dossier actuel et ses sous-dossiers pour combiner les fichiers de code."""
    dossier_script = os.getcwd() # Récupère le dossier courant où le script est lancé
    chemin_sortie = os.path.join(dossier_script, NOM_FICHIER_BUNDLE)

    print("\n--- Début de la consolidation du code ---")
    print(f"Fichier de sortie : {chemin_sortie}")
    print(f"Dossiers à exclure : {', '.join(DOSSIERS_A_EXCLURE_BUNDLE)}")

    fichiers_traites = 0

    try:
        with open(chemin_sortie, "w", encoding="utf-8") as outfile:
            for dossier_parent, sous_dossiers, fichiers in os.walk(dossier_script):

                # Exclure les dossiers spécifiés
                sous_dossiers[:] = [d for d in sous_dossiers if d not in DOSSIERS_A_EXCLURE_BUNDLE]

                for nom_fichier in fichiers:
                    if nom_fichier.endswith(EXTENSION_A_INCLURE):
                        chemin_complet_fichier = os.path.join(dossier_parent, nom_fichier)
                        chemin_relatif = os.path.relpath(chemin_complet_fichier, dossier_script).replace(os.sep, '/')

                        # Écriture du séparateur et du contenu
                        outfile.write(f"// --- FILE: {chemin_relatif} ---\n")
                        try:
                            with open(chemin_complet_fichier, "r", encoding="utf-8") as infile:
                                outfile.write(infile.read())
                                outfile.write("\n\n")
                            fichiers_traites += 1
                        except Exception as e:
                            outfile.write(f"// ERREUR DE LECTURE DU FICHIER : {e}\n\n")
                            print(f"*** Erreur lors de la lecture du fichier : {chemin_complet_fichier} -> {e}")
    except IOError as e:
        print(f"*** ERREUR CRITIQUE lors de l'écriture du fichier de sortie : {e}")
        return

    print("\n🎉 Consolidation terminée avec succès !")
    print(f"{fichiers_traites} fichiers ont été ajoutés à {NOM_FICHIER_BUNDLE}.")


def lancer_creation_zip():
    """Prépare et lance la création de l'archive zip."""
    dossier_projet = os.getcwd()
    nom_zip_sortie = f"{NOM_DOSSIER_PROJET}.zip"

    print(f"\n--- Début de la création de l'archive ZIP ---")
    print(f"Dossier source : {dossier_projet}")
    print(f"Archive de sortie : {nom_zip_sortie}")

    zip_folder_without_meta(dossier_projet, nom_zip_sortie)


def zip_folder_without_meta(folder_path, output_zip_path):
    """Crée une archive zip du dossier en excluant certains dossiers et types de fichiers."""
    try:
        with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(folder_path):
                # Ignorer les dossiers spécifiés dans la configuration
                dirs[:] = [d for d in dirs if d not in DOSSIERS_A_EXCLURE_ZIP]

                for file in files:
                    # Ignorer les fichiers par leur terminaison
                    if not any(file.endswith(ext) for ext in FICHIERS_A_EXCLURE_ZIP):
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, start=folder_path)
                        zipf.write(file_path, arcname)

        print(f"\n🎉 Archive ZIP créée avec succès : {output_zip_path}")
    except Exception as e:
        print(f"*** ERREUR CRITIQUE lors de la création de l'archive ZIP : {e}")


# Le point d'entrée principal du script
if __name__ == "__main__":
    afficher_menu()