using UnityEngine;

public class SimpleMath
{
    // Méthode simple qui ajoute deux nombres
    public int Add(int a, int b)
    {
        return a + b;
    }

    // Méthode simple qui multiplie deux nombres
    public int Multiply(int a, int b)
    {
        return a * b;
    }
}