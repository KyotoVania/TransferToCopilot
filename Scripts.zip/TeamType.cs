using UnityEngine;

// Define the possible teams for buildings and units
public enum TeamType
{
    Neutral,
    NeutralPlayer,
    NeutralEnemy,
    Player,
    Enemy
}