public enum MoodType
{
    Day,
    Night
} 