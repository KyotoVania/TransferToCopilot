public enum AudioType
{
    Music,
    SFX
} 