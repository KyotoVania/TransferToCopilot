public enum MenuState
{
    MainMenu,
    Options,
    Loading
} 