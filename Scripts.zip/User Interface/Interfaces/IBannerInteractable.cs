public interface IBannerInteractable
{
    void OnBannerClicked();
    void OnBannerHoverEnter();
    void OnBannerHoverExit();
} 