public interface IMenuCameraManager
{
    void TransitionToOptions();
    void TransitionToMainMenu();
} 