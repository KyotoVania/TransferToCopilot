using System;
using Unity.Behavior;

[BlackboardEnum]
public enum CurrentBehaviorMode
{
    Defensive,
	ObjectiveFocused
}
